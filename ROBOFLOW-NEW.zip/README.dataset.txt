# SIGN LANGUAGE > 2023-02-23 10:41pm
https://universe.roboflow.com/object-detection/sign-language-w8jyv

Provided by a Roboflow user
License: CC BY 4.0

